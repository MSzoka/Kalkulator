package com.example.szymon.calculator;

import android.graphics.Path;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.TextView;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;


public class CalcAdvanced extends AppCompatActivity {


    Double input1 = null;
    Double input2 = null;
    Method operation = null;
    Boolean firstOperation=true;
    Boolean operated = false;
    Boolean cleared = true;
    Boolean cceCycle = true;
    Boolean logarithmed = false;

    TextView textViewResult;
    HorizontalScrollView scroller;
    Button button0, button1, button2, button3, button4, button5, button6, button7, button8, button9,
            buttonDot, buttonAdd, buttonSub, buttonMul, buttonDiv, buttonEqual, buttonBspk, buttonCCe, buttonAc, buttonPositiveNegative,
             buttonSin, buttonCos, buttonTan, buttonSqrt, buttonPow2, buttonPowX, buttonRemainder, buttonLn, buttonLog;

    void setChar(String s) {
        if (!operated)
        {
            if(s.equals(".")) {
                if(!textViewResult.getText().toString().contains("."))
                    textViewResult.setText(textViewResult.getText() + s);
            }
            else if (s.equals("0") && textViewResult.getText().equals("0")) textViewResult.setText(s);
            else textViewResult.setText(textViewResult.getText() + s);
        }

        else {
            operated = false;
            textViewResult.setText(s);
        }
        cceCycle = true;
        scroller.post(new Runnable() {
            public void run() {
                scroller.fullScroll(HorizontalScrollView.FOCUS_RIGHT);
            }
        });


    }

    void setOperation(String s) {
        System.out.println(!operated);
        System.out.println(cleared);
        System.out.println(!textViewResult.getText().toString().equals(""));
        if ((!operated || input1.toString().equals(textViewResult.getText().toString())) &&  !textViewResult.getText().toString().equals("")) {
            cleared=false;

            try {
                operation = Operations.class.getMethod(s, double.class, double.class);
            } catch (NoSuchMethodException e) {
                e.printStackTrace();
            }
            if(firstOperation) input1 = Double.parseDouble(textViewResult.getText().toString());
            firstOperation=false;
            System.out.println(input1);
        }
        input2 = null;
        cceCycle = true;
        textViewResult.setText(null);

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.calc_advanced);

        button0 = (Button) findViewById(R.id.button0);
        button1 = (Button) findViewById(R.id.button1);
        button2 = (Button) findViewById(R.id.button2);
        button3 = (Button) findViewById(R.id.button3);
        button4 = (Button) findViewById(R.id.button4);
        button5 = (Button) findViewById(R.id.button5);
        button6 = (Button) findViewById(R.id.button6);
        button7 = (Button) findViewById(R.id.button7);
        button8 = (Button) findViewById(R.id.button8);
        button9 = (Button) findViewById(R.id.button9);
        buttonDot = (Button) findViewById(R.id.buttonDot);
        buttonAdd = (Button) findViewById(R.id.buttonAdd);
        buttonSub = (Button) findViewById(R.id.buttonSub);
        buttonMul = (Button) findViewById(R.id.buttonMul);
        buttonDiv = (Button) findViewById(R.id.buttonDiv);
        buttonEqual = (Button) findViewById(R.id.buttonEq);
        buttonBspk = (Button) findViewById(R.id.buttonBksp);
        buttonCCe = (Button) findViewById(R.id.buttonCCe);
        buttonAc = (Button) findViewById(R.id.buttonAc);
        buttonPositiveNegative = (Button) findViewById(R.id.buttonPositiveNegative);
        buttonSin = (Button) findViewById(R.id.buttonSin);
        buttonCos = (Button) findViewById(R.id.buttonCos);
        buttonTan = (Button) findViewById(R.id.buttonTan);
        buttonSqrt = (Button) findViewById(R.id.buttonSqrt);
        buttonPow2 = (Button) findViewById(R.id.buttonPow2);
        buttonPowX= (Button) findViewById(R.id.buttonPowX);
        buttonRemainder = (Button) findViewById(R.id.Remainder);
        buttonLn = (Button) findViewById(R.id.buttonLn);
        buttonLog = (Button) findViewById(R.id.buttonLog);

        scroller = (HorizontalScrollView) findViewById(R.id.scrollerResult);

        textViewResult = (TextView) findViewById(R.id.tv_finalResult);

        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setChar("1");
            }
        });

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setChar("2");
            }
        });

        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setChar("3");
            }
        });

        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setChar("4");
            }
        });

        button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setChar("5");
            }
        });

        button6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setChar("6");
            }
        });

        button7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setChar("7");
            }
        });

        button8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setChar("8");
            }
        });

        button9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setChar("9");
            }
        });

        button0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setChar("0");
            }
        });

        buttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setOperation("add");
            }
        });

        buttonSub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setOperation("sub");
            }
        });

        buttonMul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setOperation("mul");
            }
        });

        buttonDiv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setOperation("div");
            }
        });


        buttonEqual.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                System.out.println(cleared);
                System.out.println(input1);
                System.out.println(input2);
                if(operation!=null &&  !textViewResult.getText().toString().isEmpty() && !cleared && !textViewResult.getText().toString().equals("."))
                {
                    operated = true;
                    cceCycle = true;
                    if (input2 == null) input2 = Double.parseDouble(textViewResult.getText().toString());

                    try {
                        input1 = (double) operation.invoke(new Operations(), input1,input2);
                        if (input1.isInfinite())
                            textViewResult.setText("Nie można dzielić przez zero");
                        else if (input1.isNaN())
                            textViewResult.setText("Nie ma logarytmu z liczby ujemnej");
                        else
                            textViewResult.setText(input1.toString());

                    } catch (IllegalAccessException e) {
                        e.printStackTrace();
                    } catch (InvocationTargetException e) {
                        e.printStackTrace();
                    }

                }}
        });

        buttonDot.setOnClickListener(new View.OnClickListener() {
                                         @Override
                                         public void onClick(View v) {
                                             setChar(".");
                                         }


                                     }
        );

        buttonPositiveNegative.setOnClickListener(new View.OnClickListener() {
                                                      @Override
                                                      public void onClick(View v) {
                                                          if (!textViewResult.getText().toString().isEmpty())
                                                          {
                                                              if(textViewResult.getText().charAt(0)=='-') textViewResult.setText(textViewResult.getText().toString().substring(1));
                                                              else textViewResult.setText("-"+ textViewResult.getText());
                                                              if(operated)input1=-input1;}
                                                      }


                                                  }
        );

        buttonAc.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            textViewResult.setText(null);
                                            input1 = null;
                                            input2 = null;
                                            operation = null;
                                            operated = false;
                                            cleared=true;
                                            firstOperation=true;
                                        }


                                    }
        );

        buttonBspk.setOnClickListener(new View.OnClickListener() {
                                          @Override
                                          public void onClick(View v) {
                                              if(textViewResult.getText().length()>0) textViewResult.setText(textViewResult.getText().toString().substring(0,textViewResult.getText().length()-1));
                                          }


                                      }
        );

        buttonCCe.setOnClickListener(new View.OnClickListener() {
                                         @Override
                                         public void onClick(View v) {
                                             if(!operated) {
                                                 if (cceCycle)
                                                     textViewResult.setText(null);
                                                 else {
                                                     textViewResult.setText(null);
                                                     input1 = null;
                                                     input2 = null;
                                                     operation = null;
                                                     operated = false;
                                                     cleared = true;
                                                     firstOperation=true;
                                                 }

                                                 cceCycle = !cceCycle;
                                             }
                                         }


                                     }
        );

        buttonSin.setOnClickListener(new View.OnClickListener() {
                                          @Override
                                          public void onClick(View v) {
                                              if(!textViewResult.getText().toString().isEmpty())
                                                  textViewResult.setText(String.valueOf(Math.sin(Double.parseDouble(textViewResult.getText().toString()))));
                                          }


                                      }
        );
        buttonCos.setOnClickListener(new View.OnClickListener() {
                                         @Override
                                         public void onClick(View v) {
                                             if(!textViewResult.getText().toString().isEmpty())
                                                 textViewResult.setText(String.valueOf(Math.cos(Double.parseDouble(textViewResult.getText().toString()))));
                                         }


                                     }
        );
        buttonTan.setOnClickListener(new View.OnClickListener() {
                                         @Override
                                         public void onClick(View v) {
                                             if(!textViewResult.getText().toString().isEmpty())
                                                 textViewResult.setText(String.valueOf(Math.tan(Double.parseDouble(textViewResult.getText().toString()))));
                                         }


                                     }
        );
        buttonSqrt.setOnClickListener(new View.OnClickListener() {
                                          @Override
                                          public void onClick(View v) {
                                              operated = true;
                                              cceCycle = true;
                                              String result=new String ();
                                              if(!textViewResult.getText().toString().isEmpty())
                                              {
                                                  result=String.valueOf(Math.sqrt(Double.parseDouble(textViewResult.getText().toString())));
                                                  input1=Double.parseDouble(result);
                                              }
                                              if(!result.equals("NaN")) {
                                                  textViewResult.setText(result);

                                              }
                                              else {
                                                  textViewResult.setText("Nie ma pierwiastka z liczby ujemnej");
                                              }
                                          }


                                      }
        );
        buttonPow2.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    if(!textViewResult.getText().toString().isEmpty())
                                        textViewResult.setText(String.valueOf(Math.pow(Double.parseDouble(textViewResult.getText().toString()),2)));
                                }


                            }
        );
        buttonPowX.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setOperation("powx");
            }
        });

        buttonLn.setOnClickListener(new View.OnClickListener() {
                                         @Override
                                         public void onClick(View v) {
                                             operated = true;
                                             cceCycle = true;
                                             String result=new String ();
                                             if(!textViewResult.getText().toString().isEmpty())
                                             {
                                                result=String.valueOf(Math.log(Double.parseDouble(textViewResult.getText().toString())));
                                                input1=Double.parseDouble(result);
                                             }
                                             if(!result.equals("NaN")) {
                                                 textViewResult.setText(result);

                                             }
                                             else
                                                 textViewResult.setText("Nie ma logarytmu z liczby ujemnej");
                                         }


                                     }
        );
        buttonLog.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            operated = true;
                                            cceCycle = true;
                                            String result=new String ();
                                            if(!textViewResult.getText().toString().isEmpty())
                                            {
                                                result=String.valueOf(Math.log10(Double.parseDouble(textViewResult.getText().toString())));
                                                input1=Double.parseDouble(result);
                                            }
                                            if(!result.equals("NaN")) {
                                                textViewResult.setText(result);

                                            }
                                            else {
                                                textViewResult.setText("Nie ma logarytmu z liczby ujemnej");
                                            }

                                        }


                                    }
        );
        buttonRemainder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setOperation("percent");
            }
        });
    }
}


