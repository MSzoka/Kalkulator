package com.example.szymon.calculator;

public class Operations {
    double add (double a, double b) { return a+b; }

    double sub (double a, double b)
    {
        return a-b;
    }

    double mul (double a, double b)
    {
        return a*b;
    }

    double div (double a, double b)
    {
        return a/b;
    }

    double powx (double a, double b)
    {
        return Math.pow(a,b);
    }

    double percent (double a, double b)
    {
        return a*0.01*b;
    }

}
